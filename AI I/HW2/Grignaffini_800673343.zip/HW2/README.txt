Compile: g++ HW2.cpp -o HW2
Run: ./HW2
